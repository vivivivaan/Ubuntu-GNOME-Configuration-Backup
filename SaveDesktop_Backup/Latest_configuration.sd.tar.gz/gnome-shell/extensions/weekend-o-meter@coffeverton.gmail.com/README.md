# Weekend-O-Meter

Based on [Weekend-o-meter](https://extensions.gnome.org/extension/667/weekend-o-meter/) by jullichten.
# Hide Activities Button

A simple GNOME Shell extension to hide the Activities button from the status bar.

## Installation instructions

- [GNOME extensions web](https://extensions.gnome.org/extension/744/hide-activities-button/)
- [Extension Manager](https://flathub.org/apps/com.mattjakeman.ExtensionManager)
- [Extensions App](https://flathub.org/apps/org.gnome.Extensions)

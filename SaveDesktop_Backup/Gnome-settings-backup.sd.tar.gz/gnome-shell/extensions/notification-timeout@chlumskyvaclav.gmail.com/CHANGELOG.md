## Version 13
 * add Gnome 48 support
## Version 12
 * add Gnome 47 support
## Version 11
 * Gnome 46 support
## Version 10
 * null 'this._settings' in disable
## Version 9
 * porting to Gnome 45
 * add 'do not timeout' option
## Version 8
 * add possibility to change urgency to normal
## Version 7
 * Gnome 44 support
## Version 6
 * Gnome 43 support
## Version 5
 * remove non-debug logging
## Version 4
 * Gnome 41 support
## Version 3
 * Gnome 40 support
## Version 2
 * address e.g.o comment
## Version 1
 * initial versions

export {default as Atk} from 'gi://Atk';
export {default as Clutter} from 'gi://Clutter';
export {default as Cogl} from 'gi://Cogl';
export {default as GLib} from 'gi://GLib';
export {default as GObject} from 'gi://GObject';
export {default as GdkPixbuf} from 'gi://GdkPixbuf';
export {default as Gio} from 'gi://Gio';
export {default as Meta} from 'gi://Meta';
export {default as Mtk} from 'gi://Mtk';
export {default as Pango} from 'gi://Pango';
export {default as Shell} from 'gi://Shell';
export {default as St} from 'gi://St';


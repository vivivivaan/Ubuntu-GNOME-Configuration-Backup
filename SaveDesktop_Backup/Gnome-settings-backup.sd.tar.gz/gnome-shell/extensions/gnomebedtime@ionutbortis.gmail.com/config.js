"use strict";

export const debug = false;

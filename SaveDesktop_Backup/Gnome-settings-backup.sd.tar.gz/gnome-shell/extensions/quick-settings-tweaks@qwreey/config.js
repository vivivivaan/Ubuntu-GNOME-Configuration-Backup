export default {
    isDevelopmentBuild: false,
    isReleaseBuild: true,
    isGithubBuild: false,
    version: "2.1",
    buildNumber: 8,
    baseGTypeName: "quick-settings-tweaks_",
    loggerPrefix: "[quick-settings-tweaks]",
};

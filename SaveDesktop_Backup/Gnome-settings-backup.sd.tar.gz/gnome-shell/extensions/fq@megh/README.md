force-quit
==========

Gnome Shell Extension to add Force Quit Button

About
=====

Adds a force quit button.

Click the toolbar button, then choose the window you want to force quit.

On accidental click, right click anywhere or press <kbd>Esc</kbd> to abort the kill.


Installation
============

Install it from the [extensions site](https://extensions.gnome.org/extension/770/force-quit/)

flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system io.github.realmazharhussain.GdmSettings -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system org.torproject.torbrowser-launcher -y

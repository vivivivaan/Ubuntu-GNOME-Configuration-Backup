/** @file Provides types used throughout the codebase, mostly for storing settings. */
export {};
